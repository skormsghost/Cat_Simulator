﻿using UnityEngine;
using System.Collections;

public class poop : MonoBehaviour {

	public Transform cat;
	public Transform litter;
	public double distance;
	public GameObject prefab;


	// Update is called once per frame
	void Update () {
	
		distance=Vector3.Distance(cat.position, litter.position);

		if(distance <=2.5f){
			if(Input.GetButtonDown("Fire2")){
				//GameObject obj=Instantiate(prefab,new Vector3(litter.position.x,litter.position.y+1,litter.position.z),Quaternion.identity) as GameObject;
				GameObject obj=Instantiate(prefab,new Vector3(cat.position.x,cat.position.y,cat.position.z),Quaternion.identity) as GameObject;
			}
		}

	}
}
