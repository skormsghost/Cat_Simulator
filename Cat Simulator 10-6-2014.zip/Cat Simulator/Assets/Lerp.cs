using UnityEngine;
using System.Collections;

public class Lerp : MonoBehaviour
{
	public float smooth;
	public bool test = true;
	private Vector3 newPosition;
	public Vector3 arm;
	public Vector3 arm2;
	public double position;
	public Transform cat;
	public Transform paw;

	
	void Awake ()
	{
		newPosition = transform.position;


	}
	
	
	void Update ()
	{
		//arm = transform.localPosition;
		arm = new Vector3(cat.localPosition.x, cat.localPosition.y, cat.localPosition.z);


		arm2 = new Vector3(cat.localPosition.x +1, cat.localPosition.y, cat.localPosition.z);
		PositionChanging();

		//position.transform.localPosition= new Vector3(cat.localPosition.x, cat.localPosition.y, cat.localPosition.z);

	}
	
	
	void PositionChanging ()
	{
		//Vector3 positionA = new Vector3(5, 3, 0);
		//Vector3 positionB = new Vector3(-5, 3, 0);
		//Vector3 positionB = transform.position;

		if (test==true){
			if(Input.GetButtonDown("Fire1")){
			//newPosition = positionA;
				newPosition=arm2;
				paw.transform.rotation= Quaternion.Euler(cat.rotation.x, cat.rotation.y, cat.rotation.z);
			test=false;
			}
		}else if (test==false){
			if(Input.GetButtonDown("Fire1")){
			//newPosition = positionB;
				newPosition=arm;
				paw.transform.rotation= Quaternion.Euler(cat.localRotation.x, cat.localRotation.y, cat.localRotation.z);
			test=true;
			}
		}
		transform.position = Vector3.Lerp(transform.position, newPosition, smooth * Time.deltaTime);

	}

}