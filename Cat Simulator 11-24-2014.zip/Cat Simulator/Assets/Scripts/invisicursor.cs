﻿using UnityEngine;
using System.Collections;

public class invisicursor : MonoBehaviour {
	public Transform player;
	public Texture2D cursorTexture;
	public Texture2D cursorTexture2;
	int w = 32;
	int h = 32;
	public bool showteeth;
	public bool showcursor = true;

	private DragRigidbody drBody;

	//var pauser: boolean=false;

	// Update is called once per frame
	void Update () {


		pause pause = player.GetComponent<pause>();

		if(pause.paused==true){
			showcursor=false;
			Screen.lockCursor=false;
		}

		if(pause.paused==false){

		DragRigidbody2 drag = player.GetComponent<DragRigidbody2>();
			showteeth=drag.grab;



			//showteeth = DragRigidbody.grab;
			

//if(DragRigidBody.grab==true){
//showteeth=true;
//}else{
//showteeth=false;
//}

			
			//if(Input.GetKey(KeyCode.Escape)){
			//	showcursor=false;
			//	Screen.lockCursor=false;
			//}else{
				showcursor=true;
				Screen.lockCursor = true;
			//}
			}
	}
	void OnGUI()
	{
		if(showcursor==true){
			GUI.DrawTexture(new Rect(Screen.width / 2, Screen.height / 2, w, h), cursorTexture);
		}
		if(showteeth==true){
			GUI.DrawTexture(new Rect(Screen.width / 2, Screen.height / 2, w, h), cursorTexture2);
		}
	}
}
