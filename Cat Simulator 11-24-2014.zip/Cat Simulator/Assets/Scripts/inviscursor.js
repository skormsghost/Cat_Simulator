#pragma strict

var cursorTexture : Texture2D;
var cursorTexture2 : Texture2D;
var w : int = 32;
var h : int = 32;
var showteeth: boolean=false;
var showcursor: boolean=true;
var pauser: boolean=false;

function Start(){

}



function Update(){

//pauser = pause.paused;

	//	if(pauser==false){

showteeth = DragRigidbody.grab;

//DragRigidbody.grab=true;
/*
if(DragRigidBody.grab==true){
showteeth=true;
}else{
showteeth=false;
}
*/

if(Input.GetKey(KeyCode.Escape)){
	showcursor=false;
	Screen.lockCursor=false;
}else{
	showcursor=true;
	Screen.lockCursor = true;
}
//}
}

function OnGUI()
     {
         if(showcursor==true){
         GUI.DrawTexture(new Rect(Screen.width / 2, Screen.height / 2, w, h), cursorTexture);
         }
         if(showteeth==true){
         GUI.DrawTexture(new Rect(Screen.width / 2, Screen.height / 2, w, h), cursorTexture2);
         }
     }

