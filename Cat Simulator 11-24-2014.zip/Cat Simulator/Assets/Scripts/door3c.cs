﻿using UnityEngine;
using System.Collections;

public class door3c : MonoBehaviour {

	public Transform player;

	// Smothly open a door
	public double smooth = 2.0f;
	public double DoorOpenAngle = 90.0f;
	private bool open;
	private bool enter;
	private int count =0;
	
	private Vector3 defaultRot;
	private Vector3 openRot;
	
	void Start(){
		defaultRot = transform.eulerAngles;
		openRot = new Vector3 (defaultRot.x, defaultRot.y + 90f, defaultRot.z);
		//openRot = new Vector3 (defaultRot.x, defaultRot.y + DoorOpenAngle, defaultRot.z);
	}
	
	//Main function
	void Update (){

		pause pause = player.GetComponent<pause>();
		
		if(pause.paused==false){

		if(open){
			//Open door
			transform.eulerAngles = Vector3.Slerp(transform.eulerAngles, openRot, Time.deltaTime * 2f);
			//transform.eulerAngles = Vector3.Slerp(transform.eulerAngles, openRot, Time.deltaTime * smooth);
		}else{
			//Close door
			transform.eulerAngles = Vector3.Slerp(transform.eulerAngles, defaultRot, Time.deltaTime * 2f);
			//transform.eulerAngles = Vector3.Slerp(transform.eulerAngles, openRot, Time.deltaTime * smooth);
		}
		
		
		if(Input.GetMouseButtonDown(0) && enter){
			open = !open;
			count++;
		}
		}
	}
	
	void OnGUI(){
		if(count<1){
			if(enter){
				//GUI.Label(new Rect(Screen.width/2 - 75, Screen.height - 100, 200, 30), "Left click to open the door");
			}
		}
	}
	
	//Activate the Main function when player is near the door
	void OnTriggerEnter (Collider other){
		if (other.gameObject.tag == "Player") {
			enter = true;
		}
	}
	
	//Deactivate the Main function when player is go away from door
	void OnTriggerExit (Collider other){
		if (other.gameObject.tag == "Player") {
			enter = false;
		}
	}
}

