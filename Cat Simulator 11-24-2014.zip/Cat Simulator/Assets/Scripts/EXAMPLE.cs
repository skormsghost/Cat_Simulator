using UnityEngine;
using System.Collections;
 
[RequireComponent(typeof(Rigidbody))]
 
public class EXAMPLE : MonoBehaviour
{
    float ZSpeed = 1.0f;
    float XSpeed = 1.0f;
 
    void Start()
    {
        rigidbody.freezeRotation = true;
        rigidbody.drag = 5.0f;
            Physics.maxAngularVelocity = 100.0f;
    }
 
    void Update()
    {
        rigidbody.AddForce(new Vector3(Input.GetAxis ("Mouse X") * XSpeed,
            0, Input.GetAxis ("Mouse Y") * ZSpeed), ForceMode.Impulse);
    }
 
    void OnCollisionEnter(Collision other)
    {
        if(other.rigidbody)
        {
            if(!other.gameObject.GetComponent<ConstantForce>())
                other.gameObject.AddComponent<ConstantForce>();
            else
                other.rigidbody.constantForce.force = rigidbody.velocity;
        }
    }
 
} 