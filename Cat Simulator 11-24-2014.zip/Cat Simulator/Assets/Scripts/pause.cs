﻿using UnityEngine;
using System.Collections;

public class pause : MonoBehaviour {
	public Transform player;
	public bool paused = false;
	public bool options = false;
	public bool resume = false;
	public bool achievelist = false;
	public bool menu = true;
	public Texture2D black;
	//Transform test = Settingkeeper;

	void Update() {

		if(Input.GetKeyDown(KeyCode.P) || resume==true) {

			if (paused==false){
				Time.timeScale = 0F;
				paused=true;
			}else if(paused==true){
				Time.timeScale = 1.0F;
				Time.fixedDeltaTime = 0.02F * Time.timeScale;
				paused=false;
				resume=false;
				achievelist=false;
			}
		}
	}

	void OnGUI(){
		if(paused==true){
			if(menu==true){
			GUI.Label(new Rect(Screen.width/2 - 75, Screen.height -500 , 200, 30), "Paws Menu");
			//GUI.DrawTexture(new Rect(Screen.width / 2-75, Screen.height / 2-100, 200, 200), black);
			if (GUI.Button(new Rect(Screen.width/2 - 75, Screen.height - 400,100,50),"Resume")){
				resume=true;
				menu=false;
			}

			if (GUI.Button(new Rect(Screen.width/2 - 75, Screen.height - 300,100,50),"Achievements")){
				achievelist=true;
				menu=false;
			}
			if(GUI.Button(new Rect(Screen.width/2 - 75, Screen.height - 200,100,50),"Options")){
				options=true;
				menu=false;
			}

			GUI.Button(new Rect(Screen.width/2 - 75, Screen.height - 100,100,50),"Quit");
				//GUI.Button (Rect(10,10,50,50),"Quit")) { Application.LoadLevel("Opening Screen");
			}

			if(options==true){

				/*keepsettings keep = test.GetComponent<mute>();

				if(test.mute==false){
					if(GUI.Button(new Rect(Screen.width / 2, Screen.height / 2 - 165, 100, 50), "Mute")){
						AudioListener.pause = true;
						test.mute=true;
					}
				}else if(test.mute==true){
					
					if(GUI.Button(new Rect(Screen.width / 2, Screen.height / 2 - 165, 100, 50), "Unmute")){
						AudioListener.pause=false;
						test.mute=false;
					}
				}
				*/


				if (GUI.Button(new Rect(Screen.width/2 - 75, Screen.height - 100,100,50),"Return")){
					options=false;
					menu=true;
				}
			}


			if(achievelist==true){
				GUI.Label(new Rect(Screen.width/2 - 75, Screen.height -500 , 200, 30), "Achievements");
				achievements achieve = player.GetComponent<achievements>();
				if(achieve.tubbykins==true){
					GUI.Label(new Rect(Screen.width/2 - 35, Screen.height -400 , 200, 30), "Tubbykins Unlocked");
				}else{
					GUI.Label(new Rect(Screen.width/2 - 35, Screen.height -400 , 200, 30), "Tubbykins Locked");
				}

				if(achieve.kittyslicker==true){
					GUI.Label(new Rect(Screen.width/2 - 215, Screen.height -400 , 200, 30), "Kitty Slicker Unlocked");
				}else{
					GUI.Label(new Rect(Screen.width/2 - 215, Screen.height -400 , 200, 30), "Kitty Slicker Locked");
				}

				if(achieve.test == true){
					GUI.Label(new Rect(Screen.width/2 - 35, Screen.height -300 , 200, 30), "Test Unlocked");
				}else{
					GUI.Label(new Rect(Screen.width/2 - 35, Screen.height -300 , 200, 30), "Test Locked");
				}

				if(achieve.cheshirekat == true){
					GUI.Label(new Rect(Screen.width/2 - 215, Screen.height -300 , 200, 30), "Cheshire Kat Unlocked");
				}else{
					GUI.Label(new Rect(Screen.width/2 - 215, Screen.height -300 , 200, 30), "Cheshire Kat Locked");
				}

				if(achieve.tomkat == true){
					GUI.Label(new Rect(Screen.width/2 - 35, Screen.height -200 , 200, 30), "Tom Kat Unlocked");
				}else{
					GUI.Label(new Rect(Screen.width/2 - 35, Screen.height -200 , 200, 30), "Tom Kat Locked");
				}

				if (GUI.Button(new Rect(Screen.width/2 - 75, Screen.height - 100,100,50),"Return")){
					achievelist=false;
					menu=true;
				}
			}
		
		}
	}

}
