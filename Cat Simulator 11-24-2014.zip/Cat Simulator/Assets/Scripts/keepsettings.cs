﻿using UnityEngine;
using System.Collections;

public class keepsettings : MonoBehaviour {

	public bool mainmenu = true;
	public bool settings = false;
	public bool howtoplay = false;
	public bool mute = false;
	public GUIStyle custommain;
	public GUIStyle customtitle;
	public GUIStyle customfont;

	// Use this for initialization
	void Start () {
		DontDestroyOnLoad (transform.gameObject);
		guiText.pixelOffset = new Vector2(Screen.width/2-100, -50);
	}
	
	void OnGUI(){
		if(mainmenu==true){
			
			GUI.Label(new Rect(Screen.width/2,0,200,100),"Cat Simulator 2015", custommain);
			//guiText.text = "Cat Simulator 2015";
			
			if (GUI.Button(new Rect(Screen.width / 2,Screen.height / 2 - 150 ,100,50),"Play")){
				Application.LoadLevel("prototype");
				mainmenu=false;
			}

			if (GUI.Button(new Rect(Screen.width / 2,Screen.height / 2 -75 ,100,50),"How to Play")){
				howtoplay=true;
				mainmenu=false;
				//guiText.text="";
			}
			
			if (GUI.Button(new Rect(Screen.width / 2,Screen.height / 2 ,100,50),"Settings")){
				settings=true;
				mainmenu=false;
				//guiText.text="";
			}
			
			if (GUI.Button(new Rect(Screen.width / 2,Screen.height / 2 + 75 ,100,50),"Quit"))
				Application.Quit();
		}
		
		if(howtoplay==true){
			
			//guiText.text = "How to Play";
			GUI.Label(new Rect(Screen.width / 2,0 ,100,50),"How to Play", customtitle);
			
			GUI.Label(new Rect(Screen.width / 2,Screen.height / 2 + 75 ,100,50),"Controls:\n" +
			          "WASD and aarow keys to move\nMouse to look\nLeft and Right mouse click to swipe\nE to eat and poop\n" +
			          "F to pick up objects\nLeft Shift to sprint\nLeft Control to crouch\nLeft mouse click to open doors\n"+
			          "P to pause" ,customfont);
			
			if (GUI.Button(new Rect(Screen.width /2 +200,Screen.height /2+200 ,100,50),"Back")){
				howtoplay=false;
				mainmenu=true;
			}
		}
		
		if(settings==true){
			
			//guiText.text = "Settings";
			GUI.Label(new Rect(Screen.width / 2,0 ,100,50),"Settings", customtitle);
			
			if(mute==false){
				if(GUI.Button(new Rect(Screen.width / 2 -7, Screen.height / 2 - 165, 100, 50), "Mute")){
					AudioListener.pause = true;
					mute=true;
				}
			}else if(mute==true){
				
				if(GUI.Button(new Rect(Screen.width / 2 -7, Screen.height / 2 - 165, 100, 50), "Unmute")){
					AudioListener.pause=false;
					mute=false;
				}
			}
			
			
			
			if (GUI.Button(new Rect(Screen.width / 2 +200,Screen.height / 2 +200,100,50),"Back")){
				settings=false;
				mainmenu=true;
			}
		}
	}

}
