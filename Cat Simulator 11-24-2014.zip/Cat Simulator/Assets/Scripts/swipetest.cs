using UnityEngine;
using System.Collections;

public class swipetest : MonoBehaviour {
	public Transform right;
	public Transform left;
	public Transform player;
	public float journeyTime = 1.0F;
	public float startTime;
	public float swipetime;
	public float newtime;

	public Transform rightpaw;
	public Transform leftpaw;
	public bool swiper = false;
	public bool swipel = false;
	public Transform inipaw;

	public bool test=true;

	void Start() {
		startTime = Time.time;
		//startTime=0;

	}
	
	void Update() {

		pause pause = player.GetComponent<pause>();
		
		if(pause.paused==false){


		if(Input.GetMouseButtonDown (0)){
			if(swipel==false)
			swiper = true;
		}

		if(Input.GetMouseButtonDown (1)){
			if(swiper==false)
			swipel=true;
		}

		swiperight ();
		swipeleft();

		}

	}

	void swiperight(){
		if(swiper==false){
			rightpaw.collider.enabled=false;
			rightpaw.renderer.enabled=false;
			rightpaw.localPosition=inipaw.localPosition;
			//float fracComplete = (Time.time - startTime) / journeyTime;
			
		}
		
		if(swiper==true){
			if(test==true){
				swipetime=Time.time;
				test=false;
			}
			
			rightpaw.collider.enabled=true;
			rightpaw.renderer.enabled=true;
			
			//swipetime=Time.time;
			newtime = Time.time - swipetime;
			
			Vector3 center = (right.position + left.position) * 0.5F;
			center -= new Vector3(0, 0, 1);
			Vector3 riseRelCenter = right.position - center;
			Vector3 setRelCenter = left.position - center;

			float fracComplete = (newtime) / journeyTime;
			
			//float fracComplete = (Time.time - startTime) / journeyTime;
			//transform.position = Vector3.Slerp(riseRelCenter, setRelCenter, fracComplete);
			//transform.position += center;
			rightpaw.position = Vector3.Slerp(riseRelCenter, setRelCenter, fracComplete);
			rightpaw.position += center;

			if(newtime>.6f){
				swipetime=0;
				newtime=0;
				swiper=false;
				test=true;
				rightpaw.localPosition=inipaw.localPosition;
			}

			if(rightpaw.position == left.position){
				swipetime=0;
				newtime=0;
				swiper=false;
				test=true;
				rightpaw.localPosition=inipaw.localPosition;
			}
			
		}
		
	}
	
	void swipeleft(){
		if(swipel==false){
			leftpaw.collider.enabled=false;
			leftpaw.renderer.enabled=false;
			leftpaw.localPosition=inipaw.localPosition;
			//float fracComplete = (Time.time - startTime) / journeyTime;
		
		}
	
		if(swipel==true){
			if(test==true){
				swipetime=Time.time;
				test=false;
			}
		
			leftpaw.collider.enabled=true;
			leftpaw.renderer.enabled=true;
		
			//swipetime=Time.time;
			newtime = Time.time - swipetime;
		
			Vector3 center = (right.position + left.position) * 0.5F;
			center -= new Vector3(0, 0, 1);
			Vector3 riseRelCenter = left.position - center;
			Vector3 setRelCenter = right.position - center;
		
			float fracComplete = (newtime) / journeyTime;
		
			//float fracComplete = (Time.time - startTime) / journeyTime;
			//transform.position = Vector3.Slerp(riseRelCenter, setRelCenter, fracComplete);
			//transform.position += center;
			leftpaw.position = Vector3.Slerp(riseRelCenter, setRelCenter, fracComplete);
			leftpaw.position += center;
		
			if(leftpaw.position == right.position){
			
				swipetime=0;
				newtime=0;
				swipel=false;
				test=true;
				leftpaw.localPosition=inipaw.localPosition;
			}

			if(newtime>.6f){
				swipetime=0;
				newtime=0;
				swipel=false;
				test=true;
				leftpaw.localPosition=inipaw.localPosition;
			}
		
		}
	}
	
}