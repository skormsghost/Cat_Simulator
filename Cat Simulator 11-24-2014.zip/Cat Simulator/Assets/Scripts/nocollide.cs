﻿using UnityEngine;
using System.Collections;

public class nocollide : MonoBehaviour {
	public bool grabbed = false;
	public Transform player;
	public bool areIgnored = false; 
	// Update is called once per frame
	void Update () {
		DragRigidbody2 drag = player.GetComponent<DragRigidbody2>();
		grabbed=drag.grab;
		    areIgnored=Physics.GetIgnoreLayerCollision(8, 12);
		//if(grabbed==true){
			Physics.IgnoreLayerCollision(8, 12,grabbed);
		//}
	}

}
