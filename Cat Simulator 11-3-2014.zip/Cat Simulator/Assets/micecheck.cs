using UnityEngine;
using System.Collections;

public class micecheck : MonoBehaviour
{

		// Use this for initialization
	public GameObject mice;
	public bool checkmice=false;
	// Use this for initialization
	void OnTriggerEnter (Collider other)
	{
		if(other.gameObject==mice)
			checkmice=true;
	}
}

