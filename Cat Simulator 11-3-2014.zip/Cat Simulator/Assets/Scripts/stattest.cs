using UnityEngine;
using System.Collections;

public class stattest : MonoBehaviour
{
	public bool check = false;
	/*public Transform player;
	public float start;
	public float movement;*/
	public float distanceTravelled = 0; 
	public Vector3 lastPosition;
	public Transform player;
	public double test;
	public Transform fooddish;

	
	void Start(){
		lastPosition = transform.position;
	}
		// Update is called once per frame
		void Update (){
		food food = fooddish.GetComponent<food>();
		distanceTravelled += Vector3.Distance(player.position, lastPosition); 
		lastPosition = transform.position; 
		test=distanceTravelled;

		if(test % 5 >=0 && test % 5 <= 1){
			if(food.count>0){
				if(check==false){
			food.count--;
			check=true;
			}
			}

		}else{
			check=false;
		}

}
}

