﻿using UnityEngine;
using System.Collections;

public class achievements : MonoBehaviour {
	public Transform player;

	//timer for displaying achievments
	public float starttime = 0f;
	public float endtime = 5f;

	//achievement names
	public bool tubbykins = false;
	public bool test = false;
	public bool cheshirekat = false;

	//food
	public Transform fooddish;
	public GUIText achieve;

	//hiding places
	public Transform hiding1;
	public Transform hiding2;
	public Transform hiding3;
	public bool checkhide1=false;
	public bool checkhide2=false;
	public bool checkhide3=false;



	public bool popped = false;
	public bool cheshpop = false;
	public bool testpop = false;
	// Update is called once per frame


	void Update () {
			
		food food = fooddish.GetComponent<food>();
		checkhiding hide1 = hiding1.GetComponent<checkhiding>();
		checkhiding hide2 = hiding2.GetComponent<checkhiding>();
		checkhiding hide3 = hiding3.GetComponent<checkhiding>();

		checkhide1=hide1.checkhide;
		checkhide2=hide2.checkhide;
		checkhide3=hide3.checkhide;

		if(food.count == 10){
			tubbykins = true;
		}

		if(Input.GetKeyDown(KeyCode.U)){
			test = true;
		}

		if(checkhide1 == true && checkhide2 == true && checkhide3 == true){
			cheshirekat=true;
		}

	}




	void OnGUI(){

		if (tubbykins == true){
			if(popped==false){
				if(achieve.text=="" || achieve.text== "Achievment unlocked: Tubbykins"){
					achieve.text= "Achievment unlocked: Tubbykins";
					starttime += Time.deltaTime;


					if(starttime >= endtime){
						starttime=0;
						achieve.text="";
						popped=true;
					}//if starttime
				}//if text
			}//if popped
		}//if tubby

		if (cheshirekat == true){
			if(cheshpop==false){
				if(achieve.text=="" || achieve.text== "Achievment unlocked: Cheshire Kat"){
					achieve.text= "Achievment unlocked: Cheshire Kat";
					starttime += Time.deltaTime;
					
					
					if(starttime >= endtime){
						starttime=0;
						achieve.text="";
						cheshpop=true;
					}//if starttime
				}//if text
			}//if popped
		}//if tubby

		if (test == true){
			if(testpop==false){
				if(achieve.text=="" || achieve.text=="Achievement unlocked: Wow, you pressed U"){
					achieve.text="Achievement unlocked: Wow, you pressed U";
					starttime += Time.deltaTime;

					if(starttime >= endtime){
						achieve.text="";
						starttime=0;
						testpop=true;
					}//if startime
				}//if text
			}//if testpop
		}//if test
	}//gui
}//class
