using UnityEngine;
using System.Collections;

public class controls : MonoBehaviour 
{
	public float fatSpeed = 1;
	public float walkSpeed = 7; // regular speed
	public float crchSpeed = 3; // crouching speed
	public float runSpeed = 20; // run speed
	public GameObject fooddish;
	public int counter=0;
	public float varspeed;

	private CharacterMotor chMotor;
	private Transform tr;
	private float dist; // distance to ground
	
	// Use this for initialization
	void Start () 
	{
		chMotor =  GetComponent<CharacterMotor>();
		tr = transform;
		CharacterController ch = GetComponent<CharacterController>();
		dist = ch.height/2; // calculate distance to ground
	}
	
	// Update is called once per frame
	void FixedUpdate ()
	{
		//float vScale = 1.0f;
		food food = fooddish.GetComponent<food>();
		counter = food.count;
		float vScale = .5f;
		float speed = walkSpeed;

		/*if(counter>0){
			if(Input.GetKeyDown(KeyCode.B)){
				food.count--;
			}
		}*/

		/*if(counter >=10){
			speed = fatSpeed;
			chMotor.jumping.extraHeight = 0;
			chMotor.movement.maxBackwardsSpeed=1;
			chMotor.movement.maxSidewaysSpeed=1;

		}else if(counter<10){
			chMotor.jumping.extraHeight = 3;
			chMotor.movement.maxBackwardsSpeed=4;
			chMotor.movement.maxSidewaysSpeed=4;
			*/

		varspeed =  10;

		if(counter >= 1){
		for(int i = 1; i <= counter; i++){
			varspeed--;
		}

		if(counter >= 10){
			varspeed = .5f;
	}

		speed=walkSpeed*(varspeed *.1f);
		chMotor.jumping.extraHeight = 3 *(varspeed *.1f);
		chMotor.movement.maxBackwardsSpeed=4 *(varspeed *.1f);
		chMotor.movement.maxSidewaysSpeed=4 *(varspeed *.1f);
		}


		if ((Input.GetKey("left shift") || Input.GetKey("right shift")) && chMotor.grounded)
		{
			speed = runSpeed*(varspeed *.1f);           
		}
		
		if (Input.GetKey(KeyCode.LeftControl))
		{ // press C to crouch
			vScale = 0.48f;
			speed = crchSpeed*(varspeed *.1f); // slow down when crouching
		}
		//}
		chMotor.movement.maxForwardSpeed = speed; // set max speed
		float ultScale = tr.localScale.y; // crouch/stand up smoothly 
		
		Vector3 tmpScale = tr.localScale;
		Vector3 tmpPosition = tr.position;
		
		tmpScale.y = Mathf.Lerp(tr.localScale.y, vScale, 5 * Time.deltaTime);
		tr.localScale = tmpScale;
		
		tmpPosition.y += dist * (tr.localScale.y - ultScale); // fix vertical position      
		tr.position = tmpPosition;
		
	}
}