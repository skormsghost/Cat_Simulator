﻿using UnityEngine;
using System.Collections;

public class poop : MonoBehaviour {

	public Transform cat;
	public Transform litter;
	public double distance;
	public GameObject prefab;
	public int poopcount;
	public Transform fooddish;
	public float life = 10f;
	public bool cheat = false;

	// Update is called once per frame
	void Update () {
	
		food food = fooddish.GetComponent<food>();
		poopcount = food.count;

		distance=Vector3.Distance(cat.position, litter.position);


		if(cheat==false){
		if(distance <=2.5f){
			if(poopcount >0){
			if(Input.GetButtonDown("Fire2")){
				//GameObject obj=Instantiate(prefab,new Vector3(litter.position.x,litter.position.y+1,litter.position.z),Quaternion.identity) as GameObject;
				GameObject obj=Instantiate(prefab,new Vector3(cat.position.x,cat.position.y,cat.position.z),Quaternion.identity) as GameObject;
					Destroy (obj,life);
				if(poopcount>0){
				food.count--;
						poopcount--;
				}
			}
		}
		}
		}else if(cheat==true){
			if(Input.GetButton("Fire2")){
			GameObject obj=Instantiate(prefab,new Vector3(cat.position.x,cat.position.y,cat.position.z),Quaternion.identity) as GameObject;
			Destroy (obj,life);
			}
		}
	}
}
