using UnityEngine;
using System.Collections;

public class checkhiding : MonoBehaviour
{
	public Transform player;
	public bool checkhide = false;
		// Use this for initialization
	void OnTriggerEnter(Collider other) {
			checkhide=true;
	}
	
		// Update is called once per frame
		void Update ()
		{
	
		}
}

