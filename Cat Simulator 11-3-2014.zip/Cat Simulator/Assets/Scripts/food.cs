using UnityEngine;
using System.Collections;

public class food : MonoBehaviour
{
	public Transform empty;
	public Transform eat;
	public Transform full;
	public Transform cat;
	/*public double distancex;//distance between cat and dish of x value
	public double distancey;//distance between cat and dish of y value
	public double distancez;//distance between cat and dish of z value
	*/
	public double distance;
	public int count;
	public bool emptydisplay=false;//empty dish starts as invis and uncollidable
	public bool eatdisplay=false;//eaten dish starts as invis and uncollidable
	public bool fulldisplay=true;//full dish starts as visible and collidable

		// Update is called once per frame
		void Update ()
		{

		distance=Vector3.Distance(cat.position, full.position);
		/*
		distancex = cat.localPosition.x-full.localPosition.x;
		distancey = cat.localPosition.y-full.localPosition.y;
		distancez = cat.localPosition.z-full.localPosition.z;

		if(distancex <= 1 && distancex >= -1 && distancey <= 1 && distancey >= -1 && distancez <= 1 && distancez >= -1){
		*/
		if(distance <=2.5f){
			if(Input.GetButtonDown("Fire2")){
				count++;
				if(fulldisplay==true){
				fulldisplay=false;
				eatdisplay=true;
				}else if(eatdisplay==true){
				eatdisplay=false;
				emptydisplay=true;
				}else if(emptydisplay==true){
				emptydisplay=false;
				fulldisplay=true;
				}
			}//ifbutton
		}//if distance

			if(fulldisplay == true){
			eatdisplay=false;
			emptydisplay=false;
			empty.collider.enabled=false;
			empty.renderer.enabled=false;
			eat.collider.enabled=false;
			eat.renderer.enabled=false;
			full.collider.enabled=true;
			full.renderer.enabled=true;
			}

		if(eatdisplay == true){
			fulldisplay=false;
			emptydisplay=false;
			empty.collider.enabled=false;
			empty.renderer.enabled=false;
			eat.collider.enabled=true;
			eat.renderer.enabled=true;
			full.collider.enabled=false;
			full.renderer.enabled=false;
		}

		if(emptydisplay == true){
			fulldisplay=false;
			eatdisplay=false;
			empty.collider.enabled=true;
			empty.renderer.enabled=true;
			eat.collider.enabled=false;
			eat.renderer.enabled=false;
			full.collider.enabled=false;
			full.renderer.enabled=false;
		}
	}
}

