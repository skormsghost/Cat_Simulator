var pushPower = 2.0;
 
function OnControllerColliderHit (hit : ControllerColliderHit)
{
    var body : Rigidbody = hit.collider.attachedRigidbody;
 
    // no rigidbody
    if (body == null || body.isKinematic) { return; }
 
    
    if (hit.moveDirection.y < -0.3) { return; }
 
    // Calculate push direction from move direction,
        var pushDir = Vector3 (hit.moveDirection.x, 0, hit.moveDirection.z);
        

    // Apply the push
    body.velocity = pushDir * pushPower;
}