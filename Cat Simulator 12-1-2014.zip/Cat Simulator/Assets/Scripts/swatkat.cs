﻿using UnityEngine;
using System.Collections;

public class swatkat : MonoBehaviour {

	public int swapcount=0;
	public bool checkswap=false;

	
	// Update is called once per frame
	void Update () {
		if(swapcount==25){
			checkswap=true;
		}
	}

	void OnCollisionEnter(Collision other){
	//	if(other.tag=="test"){
			swapcount++;
	//	}
	}

}
