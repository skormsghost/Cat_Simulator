﻿using UnityEngine;
using System.Collections;

public class swipe : MonoBehaviour {

	public bool test = false;
//	public double pointx=.208562;
//	public double pointy=-.371313;
//	public double pointz=.3737448;
	public int start;
	public Transform arm;
	public Transform body;
	public GameObject target;
	void Awake(){
		target=GameObject.FindWithTag("test");

	}
	// Update is called once per frame
	void Update () {
	
		if(Input.GetButtonDown("Fire1")){
			if(test == false){
				test = true;
				collider.enabled=false;
				renderer.enabled=false;
				//arm.transform.position = new Vector3(body.localPosition.x+.208562f, body.localPosition.y-.371313f,body.localPosition.z+.3737448f);
				//arm.transform.rotation = Quaternion.Euler(0,0,0);
			}else if(test == true){
				collider.enabled=true;
				renderer.enabled=true;
				test = false;
				//arm.transform.position = new Vector3(body.localPosition.x+.208562f, body.localPosition.y-.371313f,body.localPosition.z+1.3737448f);
				//arm.transform.position = (Vector3.forward * 1);
				//arm.transform.rotation = Quaternion.Euler(0,0,0);
		}
		}
		//if(start == 
		//arm.transform.position(arm.localPosition.x+5, 0,0);
		//transform.Translate(.208562), -.371313, .3737448);
	}
}
