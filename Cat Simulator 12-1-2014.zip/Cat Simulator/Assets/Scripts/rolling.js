﻿var force: float = 100;
 
function OnControllerColliderHit(hit: ControllerColliderHit){
    if (hit.rigidbody){
       var dir = hit.normal; // get the hit direction
       dir.y = 0; // consider only the horizontal direction
       hit.rigidbody.AddForce(force * dir.normalized);
    }
}