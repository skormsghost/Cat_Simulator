﻿using UnityEngine;
using System.Collections;

public class teleport : MonoBehaviour {
	public Transform player;
	public bool test = false;
	// Use this for initialization

	void OnTriggerEnter(Collider other) {
		if(other.tag=="Player")
			player.position=new Vector3(0,0,0);
		//test=true;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
