using UnityEngine;
using System.Collections;

public class micecheck : MonoBehaviour
{

		// Use this for initialization

	//public bool checkmice=false;
	public bool tom=false;
	public int count=0;
	// Use this for initialization
	void OnTriggerEnter (Collider other){
		if(other.tag=="mice")
			count++;
	//		checkmice=true;
	}
	void OnTriggerExit(Collider other) {
		if(other.tag=="mice")
			count--;
		//checkmice=true;
	}

	void Update ()
	{
		if(count==1){
			tom=true;
		}
	}
}

