﻿using UnityEngine;
using System.Collections;

public class achievements : MonoBehaviour {
	public Transform player;

	//timer for displaying achievments
	public float starttime = 0f;
	public float endtime = 5f;

	//achievement names
	public bool tubbykins = false;
	public bool kittyslicker=false;
	public bool test = false;
	public bool cheshirekat = false;
	public bool tomkat = false;

	//food
	public Transform fooddish;
	public GUIText achieve;

	//hiding places
	public Transform hiding1;
	public Transform hiding2;
	public Transform hiding3;
	public bool checkhide1=false;
	public bool checkhide2=false;
	public bool checkhide3=false;

	public Transform bed;

	public bool popped = false;
	public bool cheshpop = false;
	public bool tompop = false;
	public bool testpop = false;
	public bool slickpop = false;
	// Update is called once per frame


	void Update () {
			
		food food = fooddish.GetComponent<food>();
		checkhiding hide1 = hiding1.GetComponent<checkhiding>();
		checkhiding hide2 = hiding2.GetComponent<checkhiding>();
		checkhiding hide3 = hiding3.GetComponent<checkhiding>();

		checkhide1=hide1.checkhide;
		checkhide2=hide2.checkhide;
		checkhide3=hide3.checkhide;

		micecheck tomk = bed.GetComponent<micecheck>();

		if(food.count == 10){
			tubbykins = true;
		}

		if(tubbykins==true){
			if(food.count == 0){
				kittyslicker = true;
			}
		}

		if(Input.GetKeyDown(KeyCode.U)){
			test = true;
		}

		if(tomk.tom==true){
			tomkat=true;
		}

		if(checkhide1 == true && checkhide2 == true && checkhide3 == true){
			cheshirekat=true;
		}

	}




	void OnGUI(){

		if (tubbykins == true){
			if(popped==false){
				if(achieve.text=="" || achieve.text== "Achievment unlocked: Tubbykins"){
					achieve.text= "Achievment unlocked: Tubbykins";
					starttime += Time.deltaTime;


					if(starttime >= endtime){
						starttime=0;
						achieve.text="";
						popped=true;
					}//if starttime
				}//if text
			}//if popped
		}//if tubby

		if (kittyslicker == true){
			if(slickpop==false){
				if(achieve.text=="" || achieve.text== "Achievment unlocked: Kitty Slicker"){
					achieve.text= "Achievment unlocked: Kitty Slicker";
					starttime += Time.deltaTime;
					
					
					if(starttime >= endtime){
						starttime=0;
						achieve.text="";
						slickpop=true;
					}//if starttime
				}//if text
			}//if popped
		}//if kittyslicker

		if (cheshirekat == true){
			if(cheshpop==false){
				if(achieve.text=="" || achieve.text== "Achievment unlocked: Cheshire Kat"){
					achieve.text= "Achievment unlocked: Cheshire Kat";
					starttime += Time.deltaTime;
					
					
					if(starttime >= endtime){
						starttime=0;
						achieve.text="";
						cheshpop=true;
					}//if starttime
				}//if text
			}//if popped
		}//if chesire

		if (tomkat == true){
			if(tompop==false){
				if(achieve.text=="" || achieve.text== "Achievment unlocked: Tom Kat"){
					achieve.text= "Achievment unlocked: Tom Kat";
					starttime += Time.deltaTime;
					
					
					if(starttime >= endtime){
						starttime=0;
						achieve.text="";
						tompop=true;
					}//if starttime
				}//if text
			}//if popped
		}//if tom

		if (test == true){
			if(testpop==false){
				if(achieve.text=="" || achieve.text=="Achievement unlocked: Wow, you pressed U"){
					achieve.text="Achievement unlocked: Wow, you pressed U";
					starttime += Time.deltaTime;

					if(starttime >= endtime){
						achieve.text="";
						starttime=0;
						testpop=true;
					}//if startime
				}//if text
			}//if testpop
		}//if test
	}//gui
}//class
